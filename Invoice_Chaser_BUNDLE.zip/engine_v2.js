/* SECOND DRAFT — NOT THE TOOL. The four fences went in (real CSV parsing, payments applied
   by invoice id, computed balances, refusals out loud) — but three faults remain, all
   demonstrated in the episode: an invoice exactly 30 days past due falls between the
   1–30 and 31–60 buckets; days past due are measured from the machine clock, not the
   books' as-of date; and a negative balance (an overpayment) is "chased". */
(function (root) {
  "use strict";
  function parseCsv(text) {
    const rows = []; let row = [], field = "", inQ = false;
    text = String(text).replace(/\r\n/g, "\n").replace(/\r/g, "\n");
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (inQ) { if (c === '"') { if (text[i + 1] === '"') { field += '"'; i++; } else inQ = false; } else field += c; continue; }
      if (c === '"' && field.trim() === "") { inQ = true; field = ""; continue; }
      if (c === ",") { row.push(field); field = ""; continue; }
      if (c === "\n") { row.push(field); if (row.some(x => x.trim())) rows.push(row.map(x => x.trim())); row = []; field = ""; continue; }
      field += c;
    }
    row.push(field); if (row.some(x => x.trim())) rows.push(row.map(x => x.trim()));
    return rows;
  }
  function cents(s) {
    const t = String(s).replace(/[$\s,]/g, "");
    if (!/^-?\d+(\.\d{1,2})?$/.test(t)) return null;
    const neg = t.startsWith("-"); const [d, f = ""] = t.replace("-", "").split(".");
    const c = parseInt(d, 10) * 100 + (f ? parseInt(f.padEnd(2, "0"), 10) : 0);
    return neg ? -c : c;
  }
  function build(invoicesCsv, paymentsCsv, opts) {
    opts = opts || {};
    // FAULT: reads the machine clock (opts.now exists only so tests can pin it)
    const today = new Date(opts.now ? opts.now + "T00:00:00Z" : Date.now());
    const asOf = Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate());
    const refused = [];
    const irows = parseCsv(invoicesCsv); irows.shift();
    const inv = new Map();
    irows.forEach((r, i) => {
      const [id, client, email, issued, due, amount, status] = r;
      const amt = cents(amount);
      const dueT = /^\d{4}-\d{2}-\d{2}$/.test(due || "") ? new Date(due + "T00:00:00Z").getTime() : NaN;
      if (!id || inv.has(id)) { refused.push({ row: i + 2, reason: !id ? "invoice id empty" : "duplicate invoice id " + id }); return; }
      if (amt === null || amt <= 0) { refused.push({ row: i + 2, reason: 'amount unreadable: "' + amount + '"' }); return; }
      if (isNaN(dueT)) { refused.push({ row: i + 2, reason: 'due date unreadable: "' + due + '"' }); return; }
      inv.set(id, { id, client, email, issued, due, dueT, amountC: amt, paidC: 0 });
    });
    const prows = parseCsv(paymentsCsv); prows.shift();
    prows.forEach((r, i) => {
      const [date, id, client, amount] = r;
      const amt = cents(amount);
      if (amt === null || amt <= 0 || !inv.has(id)) { refused.push({ row: i + 2, reason: !inv.has(id) ? "payment references no invoice: " + id : "payment amount unreadable" }); return; }
      inv.get(id).paidC += amt;
    });
    let outstandingC = 0, overdueC = 0;
    const b = { "1-30": 0, "31-60": 0, "61-90": 0, "90+": 0 };
    const chase = [];
    for (const v of inv.values()) {
      v.balanceC = v.amountC - v.paidC;
      if (v.balanceC === 0) continue;                 // FAULT: negative balances fall through
      v.days = Math.floor((asOf - v.dueT) / 86400000);
      outstandingC += v.balanceC;
      if (v.days > 0) {
        overdueC += v.balanceC;
        // FAULT: d === 30 matches neither branch
        if (v.days >= 1 && v.days < 30) b["1-30"] += v.balanceC;
        else if (v.days > 30 && v.days <= 60) b["31-60"] += v.balanceC;
        else if (v.days > 60 && v.days <= 90) b["61-90"] += v.balanceC;
        else if (v.days > 90) b["90+"] += v.balanceC;
        chase.push({ id: v.id, client: v.client, days: v.days, balanceC: v.balanceC });
      } else if (v.balanceC < 0) {
        chase.push({ id: v.id, client: v.client, days: v.days, balanceC: v.balanceC }); // chases a credit
      }
    }
    chase.sort((x, y) => y.days - x.days);
    return { outstandingC, overdueC, buckets: b, bucketSumC: b["1-30"] + b["31-60"] + b["61-90"] + b["90+"], chase, refused };
  }
  const IC_V2 = { build };
  if (typeof module !== "undefined" && module.exports) module.exports = { IC_V2 };
  root.IC_V2 = IC_V2;
})(typeof window !== "undefined" ? window : globalThis);
