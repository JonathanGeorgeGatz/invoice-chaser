#!/usr/bin/env python3
"""Independent Invoice Chaser checker — second implementation of SPEC.md, in Python.
Written from the spec, not from engine.js. Prints the output JSON for comparison.
usage: checker.py invoices.csv payments.csv '{"asOf":"2026-11-02", ...}'"""
import sys, json, re, io, csv
from datetime import date, timedelta

def read_csv(path):
    # csv module handles RFC-4180 quoting; strip whitespace, drop blank lines
    with open(path, newline="", encoding="utf-8") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f)]
    return [r for r in rows if any(c != "" for c in r)]

def cents(s):
    t = re.sub(r"[$\s,]", "", str(s))
    if not re.fullmatch(r"-?\d+(\.\d{1,2})?", t):
        return None
    neg = t.startswith("-")
    t = t.lstrip("-")
    whole, _, frac = t.partition(".")
    c = int(whole) * 100 + (int(frac.ljust(2, "0")) if frac else 0)
    return -c if neg else c

def money(c):
    sign = "-" if c < 0 else ""
    u = abs(c)
    return f"{sign}${u // 100:,}.{u % 100:02d}"

def iso(s):
    m = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", str(s).strip())
    if not m:
        return None
    try:
        return date(int(m[1]), int(m[2]), int(m[3]))
    except ValueError:
        return None

LEADS = {
    "gentle": "Just a nudge — the balance below may already be on its way to us; if so, please ignore this note.",
    "firm": "The invoices below are now well past their due dates. Could you let us know when payment will be made?",
    "final": "Despite earlier reminders, the balance below remains unpaid. Please settle it, or call us today, to avoid this account being placed on hold.",
}
SUBJECTS = {
    "gentle": "A gentle reminder from {{business}} — {{total}} outstanding",
    "firm": "{{business}}: {{count}} invoice(s) now {{oldest_days}} days past due — {{total}}",
    "final": "Final notice from {{business}} — {{total}} must be settled",
}
def default_templates():
    out = {}
    for tone in ("gentle", "firm", "final"):
        body = ("Hi {{client}},\n\n" + LEADS[tone] +
                "\n\n{{invoice_lines}}\n\nTotal outstanding: {{total}}\n\nReply to {{replyTo}} if anything above looks wrong.\n{{business}}")
        out[tone] = {"subject": SUBJECTS[tone], "body": body}
    return out

def build(inv_path, pay_path, opts):
    as_of = iso(opts.get("asOf"))
    assert as_of is not None, "asOf required"
    grace = opts.get("graceDays", 0)
    t1 = opts.get("toneGentleMax", 14)
    t2 = opts.get("toneFirmMax", 45)
    business = opts.get("business", "Bentwood Joinery")
    reply_to = opts.get("replyTo", "accounts@example.com")
    templates = opts.get("templates") or default_templates()

    refused = []
    rows = read_csv(inv_path)
    hdr = [h.lower() for h in rows[0]]
    col = {h: i for i, h in enumerate(hdr)}
    inv = {}
    order = []
    for n, r in enumerate(rows[1:], start=2):
        g = lambda k: r[col[k]] if col[k] < len(r) else ""
        iid, client = g("invoice"), g("client")
        if iid == "":
            refused.append({"kind": "invoice", "row": n, "id": "(blank)", "reason": "invoice id empty"})
            continue
        if iid in inv:
            refused.append({"kind": "invoice", "row": n, "id": iid,
                            "reason": f"duplicate invoice id {iid} — first row kept, this one refused"})
            continue
        why = []
        if client == "":
            why.append("client empty")
        amt = cents(g("amount"))
        if amt is None or amt <= 0:
            why.append('amount unreadable: "%s"' % g("amount"))
        issued = iso(g("issued"))
        if issued is None:
            why.append('issued date unreadable: "%s"' % g("issued"))
        due = iso(g("due"))
        if due is None:
            why.append('due date unreadable: "%s"' % g("due"))
        if why:
            refused.append({"kind": "invoice", "row": n, "id": iid, "reason": "; ".join(why)})
            continue
        inv[iid] = {"id": iid, "client": client, "email": g("email"), "issued": g("issued"),
                    "due": g("due"), "issued_d": issued, "due_d": due, "amount": amt,
                    "status": g("status").lower(), "paid": 0}
        order.append(iid)

    prows = read_csv(pay_path)
    phdr = [h.lower() for h in prows[0]]
    pc = {h: i for i, h in enumerate(phdr)}
    applied = 0
    for n, r in enumerate(prows[1:], start=2):
        g = lambda k: r[pc[k]] if pc[k] < len(r) else ""
        pid = g("invoice")
        why = []
        amt = cents(g("amount"))
        if amt is None or amt <= 0:
            why.append('amount unreadable: "%s"' % g("amount"))
        if iso(g("date")) is None:
            why.append('date unreadable: "%s"' % g("date"))
        if pid == "":
            why.append("invoice id empty")
        elif not why and pid not in inv:
            why.append("payment references no invoice: " + pid)
        if why:
            refused.append({"kind": "payment", "row": n, "id": pid or "(blank)", "reason": "; ".join(why)})
            continue
        inv[pid]["paid"] += amt
        applied += 1

    credits, lies, buckets, outstanding = [], [], [], []
    out_c = over_c = nyd_c = 0
    b_c = [0, 0, 0, 0]
    for iid in order:
        v = inv[iid]
        v["balance"] = v["amount"] - v["paid"]
        v["days"] = (as_of - v["due_d"]).days
        if v["balance"] < 0:
            credits.append({"id": iid, "client": v["client"], "creditC": -v["balance"]})
            continue
        if v["balance"] == 0:
            continue
        if v["status"] == "paid":
            lies.append({"id": iid, "client": v["client"], "balanceC": v["balance"]})
        outstanding.append(v)
        out_c += v["balance"]
        if v["days"] <= 0:
            nyd_c += v["balance"]
            buckets.append({"id": iid, "client": v["client"], "days": v["days"], "balanceC": v["balance"], "bucket": "not yet due"})
            continue
        over_c += v["balance"]
        b = 0 if v["days"] <= 30 else 1 if v["days"] <= 60 else 2 if v["days"] <= 90 else 3
        b_c[b] += v["balance"]
        buckets.append({"id": iid, "client": v["client"], "days": v["days"], "balanceC": v["balance"],
                        "bucket": ["1–30", "31–60", "61–90", "90+"][b]})
    buckets.sort(key=lambda x: x["id"])
    credits.sort(key=lambda x: x["id"])
    lies.sort(key=lambda x: x["id"])

    groups = {}
    for v in outstanding:
        if v["days"] > grace:
            groups.setdefault(v["client"], []).append(v)
    chase = []
    for client, lst in groups.items():
        lst.sort(key=lambda x: (x["due_d"], x["id"]))
        max_days = max(x["days"] for x in lst)
        total = sum(x["balance"] for x in lst)
        tone = "gentle" if max_days <= t1 else "firm" if max_days <= t2 else "final"
        addr, best = "", None
        for v in inv.values():
            if v["client"] == client and (best is None or v["issued_d"] > best):
                best, addr = v["issued_d"], v["email"]
        chase.append({"client": client, "emailAddr": addr, "tone": tone, "maxDays": max_days, "totalC": total,
                      "invoices": [{"id": x["id"], "issued": x["issued"], "due": x["due"], "days": x["days"], "balanceC": x["balance"]} for x in lst]})
    chase.sort(key=lambda c: (-c["maxDays"], -c["totalC"], c["client"]))

    def render(t, vars):
        return re.sub(r"\{\{(\w+)\}\}", lambda m: vars.get(m[1], m[0]), t)
    emails = []
    for c in chase:
        lines = "\n".join("- %s · issued %s · due %s · %d days past due · balance %s" %
                          (x["id"], x["issued"], x["due"], x["days"], money(x["balanceC"])) for x in c["invoices"])
        vars = {"client": c["client"], "business": business, "replyTo": reply_to,
                "count": str(len(c["invoices"])), "total": money(c["totalC"]),
                "invoice_lines": lines, "oldest_days": str(c["maxDays"])}
        tpl = templates.get(c["tone"]) or default_templates()[c["tone"]]
        emails.append({"client": c["client"], "tone": c["tone"], "to": c["emailAddr"],
                       "subject": render(tpl["subject"], vars), "body": render(tpl["body"], vars)})

    ph_ok = trace_ok = cred_ok = True
    banners = []
    settled = [v["id"] for v in inv.values() if v["balance"] <= 0]
    for e, c in zip(emails, chase):
        text = e["subject"] + "\n" + e["body"]
        if "{{" in text or "}}" in text:
            ph_ok = False
            m = re.search(r"\{\{\w+\}\}|\{\{|\}\}", text)
            banners.append("unresolved placeholder %s in the %s template" % (m[0] if m else "{{…}}", e["tone"]))
        found = sorted(cents(s) for s in re.findall(r"-?\$[\d,]+\.\d{2}", text))
        expect = sorted([x["balanceC"] for x in c["invoices"]] + [c["totalC"], c["totalC"]])
        c["amounts"] = found
        if found != expect:
            trace_ok = False
            banners.append("an amount in the %s email does not trace to the ledger" % e["client"])
        for sid in settled:
            if sid in text:
                cred_ok = False
                banners.append("settled invoice %s named in an email" % sid)
    tie = (nyd_c + sum(b_c)) == out_c
    if not tie:
        banners.append("aging buckets do not re-add to the outstanding total")
    chased = [x["id"] for c in chase for x in c["invoices"]]
    must = [v["id"] for v in outstanding if v["days"] > grace]
    cover = set(must) == set(chased) and len(chased) == len(must)
    if not cover:
        banners.append("an overdue invoice is missing from the chase list")
    trusted = ph_ok and trace_ok and cred_ok and tie and cover
    banner = "" if trusted else "DO NOT TRUST THESE REMINDERS — " + "; ".join(banners)

    return {
        "counts": {"invoiceRows": len(rows) - 1, "paymentRows": len(prows) - 1,
                   "invoicesAccepted": len(inv), "paymentsApplied": applied,
                   "refusedInvoices": sum(1 for x in refused if x["kind"] == "invoice"),
                   "refusedPayments": sum(1 for x in refused if x["kind"] == "payment"),
                   "outstandingInvoices": len(outstanding),
                   "overdueInvoices": sum(1 for v in outstanding if v["days"] >= 1),
                   "chaseClients": len(chase), "emails": len(emails) if trusted else 0},
        "money": {"outstandingC": out_c, "overdueC": over_c, "notYetDueC": nyd_c,
                  "b1C": b_c[0], "b2C": b_c[1], "b3C": b_c[2], "b4C": b_c[3]},
        "buckets": buckets, "refused": refused, "credits": credits, "statusLies": lies,
        "chase": chase,
        "emails": emails if trusted else [],
        "recon": {"bucketsTie": tie, "chaseCover": cover, "traceOk": trace_ok,
                  "placeholdersOk": ph_ok, "creditsClean": cred_ok, "trusted": trusted, "banner": banner},
    }

if __name__ == "__main__":
    print(json.dumps(build(sys.argv[1], sys.argv[2], json.loads(sys.argv[3])), ensure_ascii=False))
