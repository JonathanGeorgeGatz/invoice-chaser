/* FIRST DRAFT — NOT THE TOOL. Kept so you can see what the first prompt produced.
   Known faults (all demonstrated in the episode): splits CSV on commas so a quoted amount
   breaks the row and the row is silently skipped; trusts the status column; marks every
   invoice "paid" when the CLIENT appears anywhere in payments.csv; a due date it cannot
   read is quietly treated as not due yet. Do not use this for real books. */
(function (root) {
  "use strict";
  function build(invoicesCsv, paymentsCsv, opts) {
    opts = opts || {};
    const asOf = new Date((opts.asOf || "2026-11-02") + "T00:00:00Z").getTime();
    const ilines = String(invoicesCsv).split(/\r?\n/).filter(x => x.trim());
    const plines = String(paymentsCsv).split(/\r?\n/).filter(x => x.trim());
    const paidClients = new Set();
    for (const line of plines.slice(1)) {
      const f = line.split(",");
      if (f.length >= 3) paidClients.add(f[2].trim());
    }
    const unpaid = []; let totalOutstanding = 0; let parsed = 0, skipped = 0;
    for (const line of ilines.slice(1)) {
      const f = line.split(",");
      if (f.length !== 7) { skipped++; continue; }          // quoted commas break here — row vanishes
      const [id, client, email, issued, due, amount, status] = f.map(x => x.trim());
      parsed++;
      if (status.toLowerCase() === "paid") continue;         // trusts the typed status
      if (paidClients.has(client)) continue;                 // "the client has paid"
      const amt = parseFloat(amount.replace("$", ""));
      if (isNaN(amt)) { continue; }
      const dueT = new Date(due + "T00:00:00Z").getTime();
      const days = isNaN(dueT) ? 0 : Math.floor((asOf - dueT) / 86400000); // unreadable date -> "not due"
      totalOutstanding += amt;
      unpaid.push({ id, client, email, due, days, amount: amt, overdue: days > 0 });
    }
    return {
      totalOutstanding: Math.round(totalOutstanding * 100) / 100,
      unpaid, chase: unpaid.filter(x => x.overdue),
      counts: { parsed, skipped }
    };
  }
  const IC_V1 = { build };
  if (typeof module !== "undefined" && module.exports) module.exports = { IC_V1 };
  root.IC_V1 = IC_V1;
})(typeof window !== "undefined" ? window : globalThis);
